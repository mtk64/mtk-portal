# MTK‑Portal (MVP) – Static
- Deploy: Settings → Pages → Deploy from a branch → main / (root)
- URL: https://mtk64.github.io/mtk-portal/
- Dateien einfach direkt ins Repo-Root hochladen (keine Builds nötig).
